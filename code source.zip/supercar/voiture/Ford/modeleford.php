<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

$connexion = new mysqli($servername, $username, $password, $dbname);


if ($connexion->connect_error) {
  die("Connection failed: " . $connexion->connect_error);
}

// Récupéreration des données de la base
$query = "SELECT * FROM voiture WHERE Marque='FORD' ";
$result = $connexion->query($query);

// Construire le container Bootstrap avec les données de la voiture
$container_nouv = "";

if ($result->num_rows > 0) {

  while ($row = mysqli_fetch_assoc($result)) {
    $container_nouv .= "
<div class='col'>
  <div class='zoom'>
  <div class='card' data-bs-theme='dark' style='width: 18rem;'>
  <div class='card-img-wrapper' 
  style='width: 100%; height: 200px; overflow: hidden;  display: flex; justify-content: center; align-items: center;'>
    <img src='../../img/voitures/" . $row["img"] . "' style=' width: 100%; height: 100%; object-fit: contain;' class='card-img-top img-fluid' alt='...'>
  </div>
    <div class='card-body text-center'>
      <h5 class='card-title'>" . $row["titre"] . "</h5>
      <hr>
      <p class='card-text font-monospace text-center'>" . $row["prix"] . " $</p>
      <hr>
    <!-- Button trigger pour modal -->
    <button type='button' class='btn btn-secondary' data-bs-toggle='modal' data-bs-target='#exampleModal'>
      Afficher la fiche complète
    </button> 
    </div>
    <div class='card-body text-center'>
        <a href='../../essai/essai.php'><button type='button' class='btn btn-primary'>Demander un essai</button></a>
    </div>
    </div>
    </div>
   <br/><br/>
        <!-- Modal -->
    <div class='modal fade' id='exampleModal' data-bs-theme='dark' tabindex='-1' aria-labelledby='exampleModalLabel' aria-hidden='true'>
      <div class='modal-dialog'>
        <div class='modal-content'>
          <div class='modal-header'>
            <h1 class='modal-title fs-5 text-light' id='exampleModalLabel'>" . $row["titre"] . "</h1>
            <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
          </div>
          <div class='modal-body'>
            <ul style='color: white; font-family: Copperplate, Copperplate Gothic Light, fantasy; font-size: 100%'>
          <div align='left' class='row'>
             <div class='col-sm-6'>
                <li>Poids à vide : " . $row["poidvide"] . " Kg</li>
                <li>Longueur : " . $row["longueur"] . " mm</li>
                <li>Largeur : " . $row["largeur"] . " mm</li>
                <li>Hauteur : " . $row["hauteur"] . " mm</li>
              </div>
              <div class='col-sm-6'>             
                <li>Vitesse maximale : " . $row["vmax"] . " km/h</li>
                <li>Energie : " . $row["Carburant"] . "</li>
                <li>Réservoir : " . $row["reservoir"] . " l</li>
                <li>Places : " . $row["places"] . "</li>
              </div>
            </div>
              </ul>
          </div>
          <div class='modal-footer'>
            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Fermer</button>
            <a href='../../essai/essai.php'><button type='button' class='btn btn-primary'>Demander un essai</button></a>
          </div>
        </div>
      </div>
    </div>
   </div>
        ";
  }
} else {
  $container_nouv = "0 résultats";
}

// Fermer la connexion à la base de données
$connexion->close();
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>SUPERCAR</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet" />
  <link href="Ford.css" rel="stylesheet" />
</head>

<body>
  <br /><br />
  <!--Debut nav-->
  <nav
    class="navbar navbar-expand-lg fixed-top"
    id="arriere"
    style="background-image: url(../../img/Carbo.jpg)">
    <div class="container-fluid justify-content-center">
      <a class="navbar-brand" href="#"><img class="Logo rounded" src="../../img/Logo.png" width="100px" /></a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-underline">
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../Accueil/Accueil.php">Accueil</a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link active text-light"
              aria-current="page"
              href="../../voiture/voiture.php"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              Voitures
            </a>
            <ul class="dropdown-menu" data-bs-theme="dark">
              <li>
                <a class="dropdown-item" href="../../voiture/voiture.php">Voitures</a>
              </li>
              <li>
                <hr class="dropdown-divider" />
              </li>
              <li><a class="dropdown-item" href="../../voiture/Nissan/modelenissan.php">Nissan</a></li>
              <li><a class="dropdown-item" href="../../voiture/Ford/modeleford.php">Ford</a></li>
              <li><a class="dropdown-item" href="../../voiture/BMW/modelebmw.php">BMW</a></li>
              <li><a class="dropdown-item" href="../../voiture/Porsche/modele Porsche.php">Porshe</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="../../essai/essai.php">Demande d'Essai</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../Evenement/evenement.php">Évenement</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../contact/Contact.php">Contact</a>
          </li>
        </ul>
        <!-- Utiliser la session pour afficher un boutton de deconnexion quand connecté -->
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <form method="post" action="../../includes/logout.php">
              <button class="btn btn-danger rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                type="submit" name="logout"><img width="15px" src="../../img/se-deconnecter.png"> </button>
            </form>
            <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
              data-bs-toggle="modal" data-bs-target="#exampleModal">
              <img width="15px" src="../../img/profile.png" />
            </button>
          </div>

        <?php } else { ?>
          <div class="dropdown">
            <button
              class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center"
              style="width: 40px; height: 40px;"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              <img class="Logo" src="../../img/login.png" width="15px" />
            </button>
            <ul
              class="dropdown-menu dropdown-menu-end dropdow-menu-lg-start"
              data-bs-theme="dark">
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../../inscription/inscription.php">Inscription</a>
                </button>
              </li>
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../../inscription/connexion.php">Connexion</a>
                </button>
              </li>
            </ul>
          </div>
        <?php } ?>
      </div>
    </div>
  </nav>
  <!--Fin nav-->
  <br />
  <!--Modeles-->
  <br /><br />
  <div class="container">
    <div class="row">
      <br />
      <?php echo $container_nouv ?>
      <br />
    </div>
  </div>
  <!--Fin modeles-->
  <br /><br /><br /><br />
  <!--Debut footer-->
  <footer>
    <div class="p-5 container-fluid" id="arriere" style="background-image: url(../../img/Carbo.jpg);">
      <center><img class="Logo" src="../../img/Logo.png" width="300px" /></center>
      <br />
      <hr size="8" color="white" />
      <br /><br /><br />
      <div class="row">
        <div class="col-sm-3 mb-3 mb-sm-0 text-light">
          <a class="link-light" href="../../contact/contact.php" style="font-size: 120%;">Contactez-nous</a>
        </div>
        <div class="col-sm-3 text-light">
          <a class="link-light" href="../voiture/voiture.php" style="font-size: 120%;">Modèles</a><br /><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/BMW/modelebmw.php">BMW</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Nissan/modelenissan.php">Nissan</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Ford/modeleford.php">Ford</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Porsche/modele Porsche.php">Porshe</a>
        </div>
        <div class="col-sm-3 text-light">
          <a class="link-light" href="../../documents/conditions/conditions.php" style="font-size: 120%;">Confidentialite et mention legale</a>
        </div>
        <div class="col-sm-3 text-light">

        </div>
      </div>
      <br />
      <hr size="8" color="white" />
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-9 text-light d-flex">
            <p>Copyright © 2024 SuperCar</p>
          </div>
          <div class="col-sm-3 d-flex flex-row-reverse gap-3">
            <a href="#">
              <img class="Logom" src="../../img/reseaux/Instagram_Glyph_White.png" width="30px" /></a>
            <a href="#">
              <img class="Logom" src="../../img/reseaux/Facebook_Logo_Secondary.png" width="30px" /></a>
            <a href="#">
              <img class="Logom" src="../../img/reseaux/logo-white.png" width="30px" /></a>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--Fin footer-->

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Modal -->
  <div data-bs-theme="dark" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title text-light fs-5" id="exampleModalLabel">Information Utilisateur</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-light">Nom: <?php echo  $_SESSION["Utilisateur"]; ?>
          <p class="text-light">Mdp: <?php echo  $_SESSION["mail"]; ?>
        </div>

      </div>
    </div>
  </div>
  <!-- Fin Modal -->
</body>

</html>