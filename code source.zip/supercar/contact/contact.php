<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>SUPERCAR</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet" />
  <link
    href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
    rel="stylesheet" />
  <link href="Contact.css" rel="stylesheet" />
</head>

<body>
   <!--Debut nav-->
   <nav
        class="navbar navbar-expand-lg fixed-top"
        id="arriere"
        style="background-image: url(../img/Carbo.jpg)">
        <div class="container-fluid justify-content-center">
            <a class="navbar-brand" href="#"><img class="Logo rounded" src="../img/Logo.png" width="100px" /></a>
            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-underline">
                    <li class="nav-item">
                        <a
                            class="nav-link text-light"
                            aria-current="page"
                            href="../Accueil/Accueil.php">Accueil</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a
                            class="nav-link text-light"
                            href="../voiture/voiture.php"
                            role="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Voitures
                        </a>
                        <ul class="dropdown-menu" data-bs-theme="dark">
                            <li>
                                <a class="dropdown-item" href="../voiture/voiture.php">Voitures</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li><a class="dropdown-item" href="../voiture/Nissan/modelenissan.php">Nissan</a></li>
                            <li><a class="dropdown-item" href="../voiture/Ford/modeleford.php">Ford</a></li>
                            <li><a class="dropdown-item" href="../voiture/BMW/modelebmw.php">BMW</a></li>
                            <li><a class="dropdown-item" href="../voiture/Porsche/modele Porsche.php">Porshe</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="../essai/essai.php">Demande d'Essai</a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link text-light"
                            href="../Evenement/evenement.php">Évenement</a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link active text-light"
                            href="../contact/Contact.php">Contact</a>
                    </li>
                </ul>
                <!-- Utiliser la session pour afficher un boutton de deconnexion quand connecté -->
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <form method="post" action="../includes/logout.php">
                            <button class="btn btn-danger rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                                type="submit" name="logout"><img width="15px" src="../img/se-deconnecter.png"> </button>
                        </form>
                        <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                            data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <img width="15px" src="../img/profile.png" />
                        </button>
                    </div>

                <?php } else { ?>
                    <div class="dropdown">
                        <button
                            class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 40px; height: 40px;"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <img class="Logo" src="../img/login.png" width="15px" />
                        </button>
                        <ul
                            class="dropdown-menu dropdown-menu-end dropdow-menu-lg-start"
                            data-bs-theme="dark">
                            <li>
                                <button class="dropdown-item" type="button">
                                    <a
                                        class="dropdown-item"
                                        href="../inscription/inscription.php">Inscription</a>
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item" type="button">
                                    <a
                                        class="dropdown-item"
                                        href="../inscription/connexion.php">Connexion</a>
                                </button>
                            </li>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        </div>
    </nav>
    <!--Fin nav-->
  <!-- arrière plan video -->
  <div class="background-container">
    <video autoplay muted loop class="background-video">
      <source src="../img/voitures/ar-vid-blur.mp4" type="video/mp4">
    </video>
  </div>
  <!--- Fin video -->
  <br /><br /><br /><br />
  <!-- info contact-->
  <div class="container bg-dark bg-opacity-50 rounded" style="background-image: url(../img/Contact-us-1.jpg);
  background-size: cover;
  background-repeat: no-repeat;
  background-position: center;
  background-attachment: scroll;">
    <h1 style="color:aqua; font-family:Copperplate, Copperplate Gothic Light, fantasy;">Contactez-nous</h1>
    <p style="color:grey;">Une question ? Besoin d’un conseil pour choisir votre prochain véhicule ? Notre équipe est là pour vous aider ! N’hésitez pas à nous contacter via le formulaire ou par téléphone. Nous serons ravis de vous accompagner dans votre aventure automobile.</p><br />
  </div>
  <!--- Fin info -->
  <!--  Debut form -->
  <br /><br /><br />
  <div class="container bg-dark bg-opacity-50 rounded">
    <center>
      <form method="post" data-bs-theme="dark" action="Formulaire.php" class="formulaireContact">
        <div class="container">
          <h1 style="color: white; font-family:Copperplate, Copperplate Gothic Light, fantasy;">Nous contacter</h1>
          <br />
          <hr style="color: white">
          <div class="row">
            <div class="col-md-6 mb-3">
              <div class="contact-mf">
                <div id="contact" class="box-shadow-full">
                  <div class="row">
                    <div class="col-md-12 mb-3">
                      <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="bx bxs-user"></i></span>
                        <input type="text" name="Nom" class="form-control" id="name" placeholder="Nom" required="" />
                        <div class="validation"></div>
                      </div>
                    </div>
                    <div class="col-md-12 mb-3">
                      <div class="form-group">
                        <input type="text" class="form-control" name="Prenom" id="name" pattern="^[A-Za-zÀ-ÖØ-öø-ÿ ]+$"
                          placeholder="Prenom" required />
                        <div class="validation"></div>
                      </div>
                    </div>
                    <div class="col-md-12 mb-3">
                      <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="bx bxl-gmail"></i></span>
                        <input type="email" class="form-control" name="Mail" id="email" pattern="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$" placeholder="Adresse email" required />
                        <div class="validation"></div>
                      </div>
                    </div>
                    <div class="col-md-6 mb-3">
                      <div class="input-group">
                        <span class="input-group-text" id="basic-addon1"><i class="bx bx-phone"></i></span>
                        <input type="tel" class="form-control" name="Tel" id="number" placeholder="N° de telephone" pattern="^\+?[0-9]{1,3}?[-. ]?(\(?\d{1,4}\)?)[-. ]?\d{1,4}[-. ]?\d{1,9}$" required />
                        <div class="validation"></div>
                      </div>
                    </div>
                    <div class="col-md-12 mb-3">
                      <div class="form-group">
                        <textarea class="form-control" name="Message" rows="5" placeholder="Message" required></textarea>
                        <div class="validation"></div>
                      </div>
                    </div>
                    <div class="col-md-6 mb-3">
                      <button type="submit" id="contact-submit" class="btn btn-primary input-medium pull-right">Envoyer</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-3">
              <center>
                <div class="more-info">
                  <p class="lead">
                    <a href="https://maps.app.goo.gl/unfJ7BDKRXyr5X7v6">Afficher une carte plus grande</a>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3743.3006031008194!2d57.48672367292491!3d-20.246364181214307!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sfr!2sro!4v1730457154313!5m2!1sfr!2sro" width="350" height="300" style="border:0; border-radius: 25% 10%;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                  <p style="color: white; font-family: monospace;"><strong>Cybercity, Ebene, Île Maurice</strong></p>
                  </p>
                </div>
              </center>
            </div>
          </div>
        </div>
      </form>
    </center>
  </div>
  <br /><br />
  <!-- Fin formulaire -->

  <?php
  include('..\includes\footer.php');
  ?>
  <!-- Modal -->
  <div data-bs-theme="dark" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title text-light fs-5" id="exampleModalLabel">Information Utilisateur</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-light">Nom: <?php echo  $_SESSION["Utilisateur"]; ?>
          <p class="text-light">Mdp: <?php echo  $_SESSION["mail"]; ?>
        </div>

      </div>
    </div>
  </div>
  <!-- Fin Modal -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>