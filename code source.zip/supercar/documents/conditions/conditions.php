<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <title>Supercar</title>
  <!--Font-->

  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet" />

  <link rel="stylesheet" href="Conditions.css" />
</head>

<body>
  <!--Debut nav-->
  <nav
    class="navbar navbar-expand-lg fixed-top"
    id="arriere"
    style="background-image: url(../../img/Carbo.jpg)">
    <div class="container-fluid justify-content-center">
      <a class="navbar-brand" href="#"><img class="Logo rounded" src="../../img/Logo.png" width="100px" /></a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-underline">
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../Accueil/Accueil.php">Accueil</a>
          </li>
          <li class="nav-item dropdown">
            <a
              class="nav-link text-light"
              aria-current="page"
              href="../../voiture/voiture.php"
              role="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              Voitures
            </a>
            <ul class="dropdown-menu" data-bs-theme="dark">
              <li>
                <a class="dropdown-item" href="../../voiture/voiture.php">Voitures</a>
              </li>
              <li>
                <hr class="dropdown-divider" />
              </li>
              <li><a class="dropdown-item" href="../../voiture/Nissan/modelenissan.php">Nissan</a></li>
              <li><a class="dropdown-item" href="../../voiture/Ford/modeleford.php">Ford</a></li>
              <li><a class="dropdown-item" href="../../voiture/BMW/modelebmw.php">BMW</a></li>
              <li><a class="dropdown-item" href="../../voiture/Porsche/modele Porsche.php">Porshe</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link text-light" href="../../essai/essai.php">Demande d'Essai</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../Evenement/evenement.php">Évenement</a>
          </li>
          <li class="nav-item">
            <a
              class="nav-link text-light"
              href="../../contact/Contact.php">Contact</a>
          </li>
        </ul>
        <!-- Utiliser la session pour afficher un boutton de deconnexion quand connecté -->
        <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
          <div class="d-grid gap-2 d-md-flex justify-content-md-end">
            <form method="post" action="../../includes/logout.php">
              <button class="btn btn-danger rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                type="submit" name="logout"><img width="15px" src="../../img/se-deconnecter.png"> </button>
            </form>
            <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
              data-bs-toggle="modal" data-bs-target="#exampleModal">
              <img width="15px" src="../../img/profile.png" />
            </button>
          </div>

        <?php } else { ?>
          <div class="dropdown">
            <button
              class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center"
              style="width: 40px; height: 40px;"
              type="button"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              <img class="Logo" src="../../img/login.png" width="15px" />
            </button>
            <ul
              class="dropdown-menu dropdown-menu-end dropdow-menu-lg-start"
              data-bs-theme="dark">
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../../inscription/inscription.php">Inscription</a>
                </button>
              </li>
              <li>
                <button class="dropdown-item" type="button">
                  <a
                    class="dropdown-item"
                    href="../../inscription/connexion.php">Connexion</a>
                </button>
              </li>
            </ul>
          </div>
        <?php } ?>
      </div>
    </div>
  </nav>
  <!--Fin nav-->
  <br /><br /><br />
  <div class="card">
    <div class="card-header">
      <ul class="nav nav-tabs card-header-tabs">
        <li class="nav-item">
          <a
            class="nav-link active"
            aria-current="true"
            href="../../documents/conditions/conditions.php"
            target="_self">Conditions d'utilisation</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            href="../../documents/mentions/mentions.php"
            target="_self">Mentions legales</a>
        </li>
        <li class="nav-item">
          <a
            class="nav-link"
            href="../../documents/politique/politiques.php"
            target="_self">Politique de confidentialité</a>
        </li>
      </ul>
    </div>
    <div class="card-body">
      <center>
        <h2 class="card-title">Conditions generales d'utilisation</h2>
      </center>
      <br /><br />
      <p class="card-text">Bienvenue sur le site Supercar, une plateforme dédiée à la
        vente de voitures et à l'organisation d'événements automobiles.
        En accédant à notre site, vous acceptez de respecter les présentes
        conditions d'utilisation.</p>
      <br /><br />
      <p class="card-text">
        <strong>1. Accès et Inscription</strong><br /><br />

        L'accès à certaines fonctionnalités, telles que la demande d'essai de véhicule,
        nécessite une inscription préalable. Vous devez fournir des informations
        exactes et à jour lors de l'inscription. La création de plusieurs comptes
        ou la fourniture d'informations erronées peut entraîner la suspension ou la
        résiliation de votre compte.<br /><br />

        <strong>2. Utilisation du Site</strong><br /><br />

      <ul>
        <li>Vous êtes autorisé à naviguer sur le site, consulter les véhicules,
          et participer aux événements selon les modalités indiquées.</li>
        <li>Toute demande d'essai d'une voiture (BMW, Nissan, Ford, Porsche)
          est soumise à approbation et à la disponibilité du véhicule.</li>
        <li>L'utilisation du site pour des activités illégales, frauduleuses,
          ou pour diffuser du contenu nuisible est strictement interdite.</li>
      </ul><br />

      <strong> 3. Propriété Intellectuelle</strong><br /><br />

      Les marques, logos, images, textes et autres contenus présents sur le site
      sont protégés par des droits de propriété intellectuelle et ne peuvent être
      utilisés sans autorisation.

      <br /><br />

      <strong>4. Responsabilité</strong><br /><br />

      Supercar s'efforce de maintenir le site à jour et fonctionnel.
      Cependant, nous ne garantissons pas l'exactitude des informations fournies
      et ne serons pas responsables des éventuelles erreurs, interruptions de service,
      ou dommages résultant de l'utilisation du site.<br /><br />

      <strong>5. Responsabilité</strong><br /><br />

      Le Site n'est pas responsable des dommages directs, indirects,
      spéciaux, consécutifs ou autres résultant de l'utilisation ou de
      l'incapacité d'utiliser le Site.<br /><br />

      <strong>6. Données Personnelles</strong><br /><br />

      Les informations que vous fournissez lors de l'inscription et de l'utilisation
      du site sont traitées conformément à notre politique de confidentialité.
      En utilisant le site, vous consentez à la collecte et à l'utilisation de
      vos données dans le respect de la réglementation en vigueur.
      <br /><br />

      <strong>7. Modifications</strong><br /><br />
      Nous nous réservons le droit de modifier ces conditions d'utilisation à tout moment.
      Les utilisateurs seront informés de toute modification par un avis sur le site.

      <br /><br />

      <strong>8. Résiliation</strong><br /><br />
      Nous nous réservons le droit de résilier ou suspendre votre accès au
      Site à tout moment, pour quelque raison que ce soit, sans préavis.
      <br /><br />

      <strong>9. Loi Applicable</strong><br /><br />

      Les présentes conditions sont régies par les lois en vigueur dans le pays où est situé notre siège social.<br />
      <br /><br />
      </p>
    </div>
  </div>
  <br /><br />
  <!--Debut footer-->
  <footer>
    <div class="p-5 container-fluid" id="arriere" style="background-image: url(../../img/Carbo.jpg);">
      <center><img class="Logo" src="../../img/Logo.png" width="300px" /></center>
      <br />
      <hr size="8" color="white" />
      <br /><br /><br />
      <div class="row">
        <div class="col-sm-3 mb-3 mb-sm-0 text-light">
          <a class="link-light" href="../../contact/contact.php" style="font-size: 120%;">Contactez-nous</a>
        </div>
        <div class="col-sm-3 text-light">
          <a class="link-light" href="../voiture/voiture.php" style="font-size: 120%;">Modèles</a><br /><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/BMW/modelebmw.php">BMW</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Nissan/modelenissan.php">Nissan</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Ford/modeleford.php">Ford</a><br />
          <a class="link-light link-underline-opacity-0" href="../../voiture/Porsche/modele Porsche.php">Porshe</a>
        </div>
        <div class="col-sm-3 text-light">
          <a class="link-light" href="../../documents/conditions/conditions.php" style="font-size: 120%;">Confidentialite et mention legale</a>
        </div>
        <div class="col-sm-3 text-light">

        </div>
      </div>
      <br />
      <hr size="8" color="white" />
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-9 text-light d-flex">
            <p>Copyright © 2024 SuperCar</p>
          </div>
          <div class="col-sm-3 d-flex flex-row-reverse gap-3">
            <a href="#">
              <img class="Logom" src="../../img/reseaux/Instagram_Glyph_White.png" width="30px" /></a>
            <a href="#">
              <img class="Logom" src="../../img/reseaux/Facebook_Logo_Secondary.png" width="30px" /></a>
            <a href="#">
              <img class="Logom" src="../../img/reseaux/logo-white.png" width="30px" /></a>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!--Fin footer-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Modal -->
  <div data-bs-theme="dark" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title text-light fs-5" id="exampleModalLabel">Information Utilisateur</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-light">Nom: <?php echo  $_SESSION["Utilisateur"]; ?>
          <p class="text-light">Mdp: <?php echo  $_SESSION["mail"]; ?>
        </div>

      </div>
    </div>
  </div>
  <!-- Fin Modal -->
</body>

</html>