<?php
session_start();
?>
<html>

<head lang="fr">
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>Connexion</title>
  <link rel="stylesheet" type href="css/conn.css" />
  <link
    href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css"
    rel="stylesheet" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
    rel="stylesheet" />
</head>

<body>
  <!--Debut nav-->
  <nav
        class="navbar navbar-expand-lg fixed-top"
        id="arriere"
        style="background-image: url(../img/Carbo.jpg)">
        <div class="container-fluid justify-content-center">
            <a class="navbar-brand" href="#"><img class="Logo rounded" src="../img/Logo.png" width="100px" /></a>
            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0 nav-underline">
                    <li class="nav-item">
                        <a
                            class="nav-link active text-light"
                            aria-current="page"
                            href="../Accueil/Accueil.php">Accueil</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a
                            class="nav-link text-light"
                            href="../voiture/voiture.php"
                            role="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                            Voitures
                        </a>
                        <ul class="dropdown-menu" data-bs-theme="dark">
                            <li>
                                <a class="dropdown-item" href="../voiture/voiture.php">Voitures</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li><a class="dropdown-item" href="../voiture/Nissan/modelenissan.php">Nissan</a></li>
                            <li><a class="dropdown-item" href="../voiture/Ford/modeleford.php">Ford</a></li>
                            <li><a class="dropdown-item" href="../voiture/BMW/modelebmw.php">BMW</a></li>
                            <li><a class="dropdown-item" href="../voiture/Porsche/modele Porsche.php">Porshe</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-light" href="../essai/essai.php">Demande d'Essai</a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link text-light"
                            href="../Evenement/evenement.php">Évenement</a>
                    </li>
                    <li class="nav-item">
                        <a
                            class="nav-link text-light"
                            href="../contact/Contact.php">Contact</a>
                    </li>
                </ul>
                <!-- Utiliser la session pour afficher un boutton de deconnexion quand connecté -->
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) { ?>
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <form method="post" action="../includes/logout.php">
                            <button class="btn btn-danger rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                                type="submit" name="logout"><img width="15px" src="../img/se-deconnecter.png"> </button>
                        </form>
                        <button type="button" class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"
                            data-bs-toggle="modal" data-bs-target="#exampleModal">
                            <img width="15px" src="../img/profile.png" />
                        </button>
                    </div>

                <?php } else { ?>
                    <div class="dropdown">
                        <button
                            class="btn btn-primary rounded-circle d-flex align-items-center justify-content-center"
                            style="width: 40px; height: 40px;"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <img class="Logo" src="../img/login.png" width="15px" />
                        </button>
                        <ul
                            class="dropdown-menu dropdown-menu-end dropdow-menu-lg-start"
                            data-bs-theme="dark">
                            <li>
                                <button class="dropdown-item" type="button">
                                    <a
                                        class="dropdown-item"
                                        href="../inscription/inscription.php">Inscription</a>
                                </button>
                            </li>
                            <li>
                                <button class="dropdown-item" type="button">
                                    <a
                                        class="dropdown-item"
                                        href="../inscription/connexion.php">Connexion</a>
                                </button>
                            </li>
                        </ul>
                    </div>
                <?php } ?>
            </div>
        </div>
    </nav>
    <!--Fin nav-->
  <!-- arrière plan video -->
  <div class="background-container">
    <video autoplay muted loop class="background-video">
      <source src="../img/voitures/bm-arvid-rep.mp4" type="video/mp4">
    </video>
  </div>
  <!--- Fin video -->
  <br /><br /><br /><br />

  <center>
    <div class="container bg-dark bg-opacity-50 text-light w-75 rounded">
      <form class="user" data-bs-theme="dark" action="php/client_connect.php" method="post">
        <h1 style="font-family:Copperplate, Copperplate Gothic Light, fantasy;">Connexion</h1>
        <br />
        <?php
        if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
          echo '<h4 style="color: aqua; font-family: Copperplate;">' . $_SESSION['status'] . '</h4>';
          unset($_SESSION['status']);
        }
        ?>

        <div class="input-group input-group-lg">
          <span class="input-group-text" id="basic-addon1"><i class="bx bxs-user"></i></span>
          <input type="text"
            name="Utilisateur"
            placeholder="Nom d'utilisateur" class="form-control form-control-user" value="" required />
        </div>
        <br />
        <div class="input-group input-group-lg">
          <span class="input-group-text" id="basic-addon1"><i class="bx bxs-lock"></i></span>
          <input type="password"
            name="Mdp"
            placeholder="Mot de passe" class="form-control form-control-user" value="" required />
        </div>
        <br />
        <center><button type="submit" name="submit" class="btn btn-primary w-50">Se connecter</button></center>
        <br />
      </form>
    </div>
  </center>
  <br />
  <?php
  include('..\includes\footer.php');
  ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Modal -->
  <div data-bs-theme="dark" class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title text-light fs-5" id="exampleModalLabel">Information Utilisateur</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <p class="text-light">Nom: <?php echo  $_SESSION["Utilisateur"]; ?>
          <p class="text-light">Mdp: <?php echo  $_SESSION["mail"]; ?>
        </div>

      </div>
    </div>
  </div>
  <!-- Fin Modal -->
</body>

</html>