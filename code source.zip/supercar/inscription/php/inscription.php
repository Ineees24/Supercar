<?php
session_start();
//mettre en ligne la connexion avec la base de données
include("dbserver_connect.php");
// récupérer les contenus des variables formulaires
$utilisateur = $_POST["Utilisateur"];
$nom = $_POST["Nom"];
$prenom = $_POST["Prenom"];
$Email = $_POST["Email"];
$Tel = $_POST["Tel"];
$Motdepasse = $_POST["Mdp"];
$cmdp = $_POST["cmotdepasse"];

$email_query = "SELECT * FROM client_inscrit WHERE Email='$Email' ";
$email_query_run = mysqli_query($bdd, $email_query);
if (mysqli_num_rows($email_query_run) > 0) {
    $_SESSION['status'] = "Email déja pris. Essayer un autre";
    $_SESSION['status_code'] = "error";
    header('Location: ../../inscription/inscription.php');
} else {
    if ($Motdepasse === $cmdp) {
        //Hashage du mot de passe avec sha1
        $hmdp = sha1($Motdepasse);
        // préparer votre requête pour insérer des données dans la table PERSONNE
        $inserer = "insert into client_inscrit (Utilisateur,Nom,Prenom,Email,Tel,Mdp) values ('$utilisateur','$nom', '$prenom', '$Email', '$Tel','$hmdp')";
        // exécuter la requête avec la focntion PHP
        $query_run = mysqli_query($bdd, $inserer);
        if ($query_run) {
            // Si les données existent, envoyer un message avec la session et l'afficher dans la page destinée
            $_SESSION['status'] = "Profil ajouté";
            $_SESSION['status_code'] = "success";
            header('Location: ../../inscription/connexion.php');
        } else {
            $_SESSION['status'] = "Profil non ajouté, veuillez reéssayer";
            $_SESSION['status_code'] = "error";
            header('Location: ../../inscription/inscription.php');
        }
    } else {
        $_SESSION['status'] = "Mot de passe incorrecte";
        $_SESSION['status_code'] = "warning";
        header('Location: ../../inscription/inscription.php');
    }
}
// fermeture de la connexion avec la base de données
mysqli_close($bdd);
