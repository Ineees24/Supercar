<?php
session_start();

//definition du paramètre serveur et table
include("dbserver_connect.php");

//capture des valeurs mit dans les inputs en utilisant la méthode POST
if (isset($_POST['submit'])) {
    $utilisateur = $_POST['Utilisateur'];
    $motdepasse = $_POST['Mdp'];
    $hash = sha1($motdepasse);

    //attribution de la requête sql dans une variable
    $sql = "SELECT * from `supercar`.`client_inscrit` WHERE Utilisateur = '$utilisateur'";


    //execution de la requête sql mit dans une variable 
    $rslt = mysqli_query($bdd, $sql);

    if (mysqli_num_rows($rslt) > 0) {
        // Récupérer le résultat sous forme de tableau associatif
        $row = mysqli_fetch_assoc($rslt);
        $hashpass = $row['Mdp'];  // Le mot de passe haché

    } else {
        // Email non trouvé
        $_SESSION['status'] = "Utilisateur non trouvé";
        header('Location: ../../inscription/connexion.php');
        exit();
    }
    // Vérification du mot de passe avec le hachage
    if ($hash == $hashpass) {
        // Si la vérification est réussie, démarrer la session utilisateur
        $mail = $ligne['Email'];
        $_SESSION["logged_in"] = true;
        $_SESSION["Utilisateur"] = $utilisateur;
        $_SESSION["mail"] = $mail;
        header("Location: ../../Accueil/Accueil.php");
        exit();  // Toujours ajouter exit() après une redirection
    } else {
        // Mot de passe incorrect
        $_SESSION['status'] = "Mot de passe incorrect";
        header('Location: ../../inscription/connexion.php');
        exit();
    }
    /*
    //verification de la valeur retourné et validation ou invalidation
    $ligne = mysqli_fetch_array($rslt, MYSQLI_ASSOC);

    $nbligne = mysqli_num_rows($rslt);
    if ($nbligne == 1) {
        $mail = $ligne['Email'];
        $_SESSION["logged_in"] = true;
        $_SESSION["Utilisateur"] = $utilisateur;
        $_SESSION["mail"] = $mail;
        header("Location: ../../Accueil/Accueil.php");
    } else {
        echo ("Identifiants incorrects");
        header("Location: ../../inscription/connexion.php");
    }
        */
}
